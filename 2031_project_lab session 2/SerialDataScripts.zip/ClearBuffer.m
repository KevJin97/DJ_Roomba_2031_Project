if s.bytesavailable > 0
    fread(s, s.bytesavailable);
end
