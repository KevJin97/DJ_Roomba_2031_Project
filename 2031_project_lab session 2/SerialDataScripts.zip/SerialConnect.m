s = serial('COM1','BaudRate',9600, 'InputBufferSize',1024);
fopen(s)